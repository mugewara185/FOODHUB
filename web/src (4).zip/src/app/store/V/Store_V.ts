import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { 
  persistStore, 
  persistReducer, 
  FLUSH, 
  REHYDRATE, 
  PAUSE, 
  PERSIST, 
  PURGE, 
  REGISTER 
} from "redux-persist";
import storage from "redux-persist/lib/storage";
import storageSession from "redux-persist/lib/storage/session";
import { IS_DEV } from "../../../core/config/app.config";

import authReducer from "../../../features/auth/authSlice";
import cartReducer from "../../../features/cart/cartSlice";
import restaurantReducer from "../../../features/restaurant/restaurantSlice";
import uislice from "../../../features/ui/uiSlice";

// Import state initializers
import { initializeAllStatesFromFactory } from "./stateInitializers";

// Initialize root reducer
const rootReducer = combineReducers({
  auth: authReducer,
  cart: cartReducer,
  restaurants: restaurantReducer,
  ui: uislice,
});

// Select storage engine: session isolation mode uses sessionStorage for multi-tab testing
const SESSION_ISOLATION_KEY = "zom2_dev_session_isolation";
const useSessionStorage = IS_DEV && localStorage.getItem(SESSION_ISOLATION_KEY) === "true";
const storageEngine = useSessionStorage ? storageSession : storage;

const persistConfig = {
  key: "root",
  version: 1,
  storage: storageEngine,
  whitelist: ["auth", "cart"], // Preserving auth and cart
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

/**
 * Create store with factory-initialized state
 * Pre-loads realistic data from unifiedFactory on app start
 * 
 * Best Practices:
 * 1. Preloaded state is combined with persisted state
 * 2. Cart and Auth are persisted across sessions
 * 3. Restaurant data is re-generated on each app start (CMS data should come from API)
 * 4. Error handling gracefully falls back to empty states
 */
const store = configureStore({
  reducer: persistedReducer,
  preloadedState: initializeAllStatesFromFactory({
    restaurantCount: 20,
    foodItemCount: 50,
    userCount: 5,
    orderCount: 5,
    reviewCount: 10,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  }) as any, // Type assertion needed because redux-persist adds _persist property after initialization
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
  devTools: IS_DEV, //true
});

console.log("Redux store initialized with factory data:", store.getState());

export const persistor = persistStore(store);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export default store;