import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ProtectedRoute from '../../features/auth/protectedRoute';
//user routes
import MainLayout from '../../shared/layout/MainLayout';

import {
  Home,
  Login,
  Signup,
  ForgotPassword,
  ResetPassword,
  RestaurantDetail,
  Checkout,
  Cart,
  Restaurants,
  Favourites,
  Profile,
  Notifications,
  SearchPage,
  Settings,
  Orders,
  OrderTracking,
  // Addresses,
  // Checkout 
  // order details,
  // Search,
  // NotFound,
  // ... other user pages
} from '@pages/index';

// delivery partner routes
import { PartnerLayout ,AvailableOrders, ActiveDelivery, DeliveryHistory, Earnings, PartnerDashboard, PartnerProfile, Support, PartnerSettings  } from '@pages/_deliveryPartner';

// owner routes
import {
  OwnerLayout, OwnerDashboard, OwnerSettings, 
  SalesReport, 
  OrderQueue, 
  BusinessHours, 
  RestaurantProfile, 
  StaffManagement,
  AddmenuItem, MenuItems, Categories, 
} from '@pages/_ownerPages';

//admin routes
import { 
 AdminLayout, Promotions, Reports, Settings as AdminSettings, Users,
AdminProfile, AdminDashboard, OrdersList, RestaurantsList, AddRestaurant
 } from '../../pages/admin';

 import DevLayout from '@/core/dev/ui/layout/DevLayout';
 import DevDashboard from '@core/dev/ui/Dashboard'

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* dev tools */}
      <Route path="/dev/*" element={<DevLayout />}>
        <Route path='dashboard' element={<DevDashboard />} />
         {/* Add more dev tool routes here */}
      </Route>

      {/* user routes */}
      <Route path="/" element={<MainLayout />}>
        {/* Public Routes */}
        <Route index element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="signup" element={<Signup />} />
        <Route path="forgot-password" element={<ForgotPassword />} />
        <Route path="reset-password" element={<ResetPassword />} />
        <Route path="restaurants" element={<Restaurants />} />
        <Route path="restaurants/:id" element={<RestaurantDetail />} />
        <Route path='favorites' element={<Favourites />} />
        <Route path='notification' element={<Notifications />} />
        <Route path='search' element={<SearchPage />} />
        <Route path='settings' element={<Settings />} />
        {/* Protected Routes */}
        <Route path="profile" element={
          <ProtectedRoute allowedRoles={['user', 'admin']}>
            <Profile />
          </ProtectedRoute>
        } />
        <Route path="cart" element={
          <ProtectedRoute allowedRoles={['user', 'admin']}>
            <Cart />
          </ProtectedRoute>
        } />
        <Route path="checkout" element={
          <ProtectedRoute allowedRoles={['user', 'admin']}>
            <Checkout />
          </ProtectedRoute>
        } />
        <Route path="orders" element={
          <ProtectedRoute allowedRoles={['user', 'admin']}>
            <Orders />
          </ProtectedRoute>
        } />
        <Route path='orders/:id/track' element={<OrderTracking />} />
        {/* ... other routes */}

        {/* Public Routes */}
        {/* <Route path="search" element={<Search />} /> */}

        {/* 404 */}
        {/* <Route path="*" element={<NotFound />} /> */}
      </Route>

      {/* partner routes */}
      <Route path="/partner/*" element={
        <ProtectedRoute allowedRoles={['delivery_partner']}>
          <PartnerLayout />
        </ProtectedRoute>
      } >
        <Route index element={<PartnerDashboard />} />
        <Route path='orders' element={<AvailableOrders />} />
        <Route path='active' element={<ActiveDelivery />} />
        <Route path='profile' element={<PartnerProfile />} />
        <Route path='history' element={<DeliveryHistory />} />
        <Route path='earnings' element={<Earnings />} />
        <Route path='support' element={<Support />} />
        <Route path='settings' element={<PartnerSettings />} />
      </Route>

      {/* owner routes  */}
      <Route path="/owner/*" element={
        <ProtectedRoute allowedRoles={['restaurant_owner']}>
          <OwnerLayout />
        </ProtectedRoute>
      } >
        <Route index element={<OwnerDashboard />} />
        <Route path='settings' element={<OwnerSettings />} />
        <Route path='analytics/salesreport' element={<SalesReport />} />
        <Route path='menu/add-item' element={<AddmenuItem />} />
        <Route path='menu/menu-items' element={<MenuItems />} />
        <Route path='menu/categories' element={<Categories />} />
        <Route path='orderqueue' element={<OrderQueue />} />
        <Route path='profile/business-hours' element={<BusinessHours />} />
        <Route path='restaurantprofile' element={<RestaurantProfile />} />
        <Route path='staffmanagement' element={<StaffManagement />} />
      </Route>

      {/* admin routes */}
      <Route path="/admin/*" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <AdminLayout />
        </ProtectedRoute>
      } >
        <Route index element={<AdminDashboard />} />
        <Route path='orders' element={<OrdersList />} />
        {/* <Route path='orders/:id/track' element={<OrderTracking />} (//user component) for now /> */}
        <Route path='restaurants' element={<RestaurantsList />} />
        <Route path='restaurants/add' element={<AddRestaurant />} />
        <Route path='promotions' element={<Promotions />} />
        <Route path='reports' element={<Reports />} />
        <Route path='settings' element={<AdminSettings />} />
        <Route path='users' element={<Users />} />
        <Route path='profile' element={<AdminProfile />} />
      </Route>

    </Routes>
  );
};

export default AppRoutes;