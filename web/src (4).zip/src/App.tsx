import React from "react";
import {AuthProvider} from './contexts/AuthContext';
import AppRoutes from "./app/routes";
// import { ErrorBoundary } from "./shared/components/ErrorBoundary";

const App:React.FC =()=>{
  // console.log('%c<App/>','color:orange')
  return (
    // <ErrorBoundary>
      <AuthProvider>
        <AppRoutes/>
      </AuthProvider>
    // </ErrorBoundary>
  )
}

export default App;